#!/usr/bin/env python3
from main_brain_games import main1
main1()
