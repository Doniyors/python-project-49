import sys
import random


# Импортируйте функцию генератора контента из игры brain_prime
from brain_games.games.brain_prime import generate_prime


def main():
    print("Welcome to the Brain Games!")
    name = input("May I have your name? ")
    print(f"Hello, {name}!")
    print('Answer "yes" if given number is prime. Otherwise answer "no".')

    # Определите переменные для условий победы
    correct_answers_to_win = 3
    user_correct_answers = 0

    # Определите функцию для генерации контента из игры
    def brain_prime_content_creator():
        return generate_prime()

    # Определите функцию для получения первого элемента из контента
    def car(content):
        return content[0]

    # Определите функцию для получения второго элемента из контента
    def cdr(content):
        return content[1]

    # Определите функцию для выполнения игры
    def run_game(game_content_creator):
        while user_correct_answers < correct_answers_to_win:
            game_content = game_content_creator()
            task = car(game_content)
            correct_answer = cdr(game_content)

            # Вместо прямого вызова игры, выведите задачу и получите ответ пользователя
            print(f'Question: {task}')
            user_answer = input("Your answer: ")

            # Проверьте ответ пользователя и обновите счетчик правильных ответов
            if user_answer.lower() == correct_answer:
                print('Correct!')
                user_correct_answers += 1
            else:
                print(f"'{user_answer}' is the wrong answer ;(.")
                print(f"The correct answer was '{correct_answer}'.")
                break

    # Вызовите функцию выполнения игры, передавая функцию генератора контента
    run_game(brain_prime_content_creator)

    # Поздравьте пользователя при достижении условий победы
    if user_correct_answers == correct_answers_to_win:
        print("Congratulations, " + name + "!")


if __name__ == '__main__':
    main()