def welcome_user():
    print("Welcome to the Brain Games!")
